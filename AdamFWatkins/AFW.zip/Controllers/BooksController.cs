﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdamFWatkins.Models;

namespace AdamFWatkins.Controllers
{
    public class BooksController : Controller
    {
        //
        // GET: /Books/
        dbContext db = new dbContext();

        public ActionResult Index()
        {
            return RedirectToRoute("Books", new { pageNum = 1 });
        }

        public ActionResult Page(string pageNum)
        {
            var allBooks = db.Books.OrderBy(b => b.displayOrder);
            IQueryable<Book> filteredBooks;

            int intPageNum; 
            int.TryParse(pageNum, out intPageNum);

            if (intPageNum == 0)
            {
                return RedirectToRoute("Books", new { pageNum = 1 });
            }

            ViewBag.CurrentPage = intPageNum;
            int numPerPage = 6;


            if (allBooks.Count() > numPerPage)
            {

                int numPages = (int)Math.Ceiling((double)allBooks.Count() / numPerPage);

                if (intPageNum > numPages)
                {
                    //Redirect them to a valid page number. 
                    return RedirectToRoute("Books", new { pageNum = 1 });
                }
                else
                {

                    if (intPageNum == 1)
                    {
                        ViewBag.ShowBackButtonVisible = "none";
                    }
                    else
                    {
                        ViewBag.ShowBackButtonVisible = "";
                        ViewBag.PreviousPage = intPageNum - 1;
                    }


                    if (intPageNum == numPages)
                    {
                        ViewBag.ShowMoreButtonVisible = "none";
                    }
                    else
                    {
                        ViewBag.ShowMoreButtonVisible = "";
                        ViewBag.NextPage = intPageNum + 1;
                    }

                    filteredBooks = allBooks.Skip((intPageNum - 1) * numPerPage).Take(numPerPage);

                }

            }
            else
            {
                ViewBag.ShowMoreButtonVisible = "none";
                ViewBag.ShowBackButtonVisible = "none";
                filteredBooks = allBooks.Take(numPerPage);


            }

            return View(filteredBooks);
        }

        public ActionResult View(string id)
        {
            int bookId; 
            int.TryParse(id, out bookId);

            if (bookId == 0)
            {
                return RedirectToRoute("Books", new { pageNum = 1 });

            }

            var book = db.Books.Where(b => b.id == bookId).FirstOrDefault();

            if (book != null)
            {
                return View(book);
            }
            else
            {
                return RedirectToRoute("Books", new { pageNum = 1 });
            }

            
        }

    }
}
