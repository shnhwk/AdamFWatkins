﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdamFWatkins.Models;

namespace AdamFWatkins.Controllers
{
    public class ContactController : Controller
    {
        //
        // GET: /Contact/


        dbContext db = new dbContext();

        public ActionResult Index()
        {
            SiteText st = db.SiteTexts.Where(s => s.key == "ContactContent").FirstOrDefault();
            return View(st);
        }

    }
}
